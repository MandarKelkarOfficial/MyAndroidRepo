package com.example.androidosdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.ToggleButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.apache.commons.lang3.math.*;


public class MainActivity extends AppCompatActivity {
    ToggleButton darkmode;
    Button calculator, Ex_Rate, Unit_Con, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20;
    EditText e1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(getWindow().FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        calculator = (Button) findViewById(R.id.b1);
        Ex_Rate = (Button) findViewById(R.id.b2);
        Unit_Con = (Button) findViewById(R.id.b3);

        b1 = (Button) findViewById(R.id.bx1);
        b2 = (Button) findViewById(R.id.bx2);
        b3 = (Button) findViewById(R.id.bx3);
        b4 = (Button) findViewById(R.id.bx4);
        b5 = (Button) findViewById(R.id.bx5);
        b6 = (Button) findViewById(R.id.bx6);
        b7 = (Button) findViewById(R.id.bx7);
        b8 = (Button) findViewById(R.id.bx8);
        b9 = (Button) findViewById(R.id.bx9);
        b10 = (Button) findViewById(R.id.mul);
        b11 = (Button) findViewById(R.id.c);
        b12 = (Button) findViewById(R.id.mod);
        b13 = (Button) findViewById(R.id.clear);
        b14 = (Button) findViewById(R.id.div);
        b15 = (Button) findViewById(R.id.zero);
        b16 = (Button) findViewById(R.id.zero2);
        b17 = (Button) findViewById(R.id.add);
        b18 = (Button) findViewById(R.id.sub);
        b19 = (Button) findViewById(R.id.dot);
        b20 = (Button) findViewById(R.id.equals);

        e1 = (EditText) findViewById(R.id.result);


        Ex_Rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), ex_rate.class);
                startActivity(i);

            }
        });

        Unit_Con.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent f = new Intent(getApplicationContext(), uc.class);
                startActivity(f);

            }
        });

        // Set listeners for numeric buttons
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(e1.getText() + "1");
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(e1.getText() + "2");
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(e1.getText() + "3");
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(e1.getText() + "4");
            }
        });

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(e1.getText() + "5");
            }
        });

        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(e1.getText() + "6");
            }
        });

        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(e1.getText() + "7");
            }
        });

        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(e1.getText() + "8");
            }
        });

        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(e1.getText() + "9");
            }
        });

        b15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(e1.getText() + "0");
            }

        });


        b14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(e1.getText() + "/");
            }
        });

        b10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(e1.getText() + "*");
            }
        });

        b11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText("");
            }
        });

        b12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText("%");
            }
        });

        b16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(e1.getText() + "00");
            }
        });

        b17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(e1.getText() + "+");
            }
        });

        b18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(e1.getText() + "-");
            }
        });

        b19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e1.setText(e1.getText() + ".");
            }
        });


        b20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String expr = e1.getText().toString();
                List<String> tokens = tokenize(expr);

                if (tokens.size() < 3) {
                    // Not a valid expression
                    e1.setText("Error");
                    return;
                }

                // Evaluate the expression using a stack
                Stack<Double> stack = new Stack<>();
                stack.push(Double.parseDouble(tokens.get(0)));

                for (int i = 1; i < tokens.size(); i += 2) {
                    String op = tokens.get(i);
                    double operand = Double.parseDouble(tokens.get(i + 1));

                    if (op.equals("+")) {
                        stack.push(operand);
                    } else if (op.equals("-")) {
                        stack.push(-operand);
                    } else if (op.equals("*")) {
                        stack.push(stack.pop() * operand);
                    } else if (op.equals("/")) {
                        stack.push(stack.pop() / operand);
                    } else if (op.equals("%")) {
                        stack.push(stack.pop() % operand);
                    }
                }

                // Sum the stack to get the final result
                double result = 0.0;
                while (!stack.empty()) {
                    result += stack.pop();
                }

                e1.setText(Double.toString(result));
            }
        });


    }


    private List<String> tokenize(String expr) {
        List<String> tokens = new ArrayList<>();

        String curr = "";
        for (char c : expr.toCharArray()) {
            if (Character.isDigit(c) || c == '.') {
                curr += c;
            } else if (curr.length() > 0) {
                tokens.add(curr);
                curr = "";
            }

            if (c == '+' || c == '-' || c == '*' || c == '/' || c == '%') {
                tokens.add("" + c);
            }
        }

        if (curr.length() > 0) {
            tokens.add(curr);
        }

        return tokens;
    }


}
