package com.example.androidosdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class ex_rate extends AppCompatActivity {
    ToggleButton darkmode;
    Button calculator, Unit_Con, convert;
    EditText ex1;
    Spinner sp1;
    TextView tx1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(getWindow().FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.ex_rate);


        calculator = (Button) findViewById(R.id.b1);
        convert = (Button) findViewById(R.id.convert);
        Unit_Con = (Button) findViewById(R.id.b3);


        sp1 = findViewById(R.id.currency_spinner);
        ex1 = (EditText) findViewById(R.id.value_to_convert);
        tx1 = (TextView) findViewById(R.id.converted_value);

//        convert.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(ex_rate.this, "Unit Converted", Toast.LENGTH_SHORT).show();
//            }
//        });

        convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the currency code selected in the Spinner
                String currencyCode = sp1.getSelectedItem().toString();

                // Get the value to convert
                String valueToConvert = ex1.getText().toString();

                // Convert the value to the selected currency
                double convertedValue = performCurrencyConversion(currencyCode, Double.parseDouble(valueToConvert));

                // Set the converted value in the TextView
                tx1.setText(String.format("%.2f", convertedValue) + " " + currencyCode);
            }
        });


        Unit_Con.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent f = new Intent(getApplicationContext(), uc.class);
                startActivity(f);

            }
        });

        calculator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent j = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(j);

            }
        });


    }

    // Method to perform currency conversion
    private double performCurrencyConversion(String currencyCode, double valueToConvert) {
        // Perform the currency conversion calculation
        // You can replace this with your own currency conversion logic
        double conversionRate = getConversionRate(currencyCode); // Get the conversion rate for the selected currency
        double convertedValue = valueToConvert * conversionRate; // Convert the value to the selected currency

        return convertedValue;
    }

    // Method to get the conversion rate for a currency code
    private double getConversionRate(String currencyCode) {
        // You can replace this with your own currency conversion rate API
        // Here, we are using a hardcoded conversion rate for demonstration purposes only
        switch (currencyCode) {
            case "USD":
                return 0.013; // 1 INR = 0.013 USD
            case "EUR":
                return 0.011; // 1 INR = 0.011 EUR
            case "GBP":
                return 0.0095; // 1 INR = 0.0095 GBP
            case "JPY":
                return 1.45; // 1 INR = 1.45 JPY
            case "AUD":
                return 0.017; // 1 INR = 0.017 AUD
            default:
                return 0;
        }
    }
}

