package com.example.androidosdemo;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;

import androidx.appcompat.app.AppCompatActivity;

public class uc extends AppCompatActivity {

    private EditText inputEditText;
    private TextView resultTextView;
    private Spinner selectUnitSpinner;
    private Spinner resultUnitSpinner;
    private Button convertButton;

    private String[] unitsArray;
    private String selectUnit;
    private String resultUnit;
    Button calculator, Ex_rate;

    //    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(getWindow().FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.uc);

        // Get references to UI components
        inputEditText = findViewById(R.id.et_from);
        resultTextView = findViewById(R.id.et_to);
        selectUnitSpinner = findViewById(R.id.sp_from_unit);
        resultUnitSpinner = findViewById(R.id.sp_to_unit);
        convertButton = findViewById(R.id.btn_convert);
        calculator = findViewById(R.id.b1);
        Ex_rate = findViewById(R.id.b2);

        // Set up the units spinner
        unitsArray = getResources().getStringArray(R.array.units_array);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, unitsArray);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        selectUnitSpinner.setAdapter(adapter);
        resultUnitSpinner.setAdapter(adapter);
        selectUnit = unitsArray[0];
        resultUnit = unitsArray[0];

        // Set up the convert button click listener
        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convert();
            }
        });

        calculator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent j = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(j);
            }
        });

        Ex_rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), ex_rate.class);
                startActivity(i);
            }
        });
    }


    private void convert() {
        // Get the input value
        double inputValue = Double.parseDouble(inputEditText.getText().toString());

        // Get the selected units
        String fromUnit = selectUnitSpinner.getSelectedItem().toString();
        String toUnit = resultUnitSpinner.getSelectedItem().toString();

        // Get the conversion factor
        double conversionFactor = getConversionFactor(fromUnit, toUnit);

        // Calculate the result
        double resultValue = inputValue * conversionFactor;

        // Set the result text view
        resultTextView.setText(String.format("%f %s = %f %s", inputValue, fromUnit, resultValue, toUnit));
    }


    private double getConversionFactor(String fromUnit, String toUnit) {
        double fromFactor = 1.0;
        double toFactor = 1.0;

        switch (fromUnit) {
            case "Millimeters":
                fromFactor = 0.001;
                break;
            case "Centimeters":
                fromFactor = 0.01;
                break;
            case "Meters":
                fromFactor = 1.0;
                break;
            case "Kilometers":
                fromFactor = 1000.0;
                break;
            case "Inches":
                fromFactor = 0.0254;
                break;
            case "Feet":
                fromFactor = 0.3048;
                break;
            case "Yards":
                fromFactor = 0.9144;
                break;
            case "Miles":
                fromFactor = 1609.344;
                break;
        }

        switch (toUnit) {
            case "Millimeters":
                toFactor = 0.001;
                break;
            case "Centimeters":
                toFactor = 0.01;
                break;
            case "Meters":
                toFactor = 1.0;
                break;
            case "Kilometers":
                toFactor = 1000.0;
                break;
            case "Inches":
                toFactor = 0.0254;
                break;
            case "Feet":
                toFactor = 0.3048;
                break;
            case "Yards":
                toFactor = 0.9144;
                break;
            case "Miles":
                toFactor = 1609.344;
                break;
        }

        return toFactor / fromFactor;
    }

}